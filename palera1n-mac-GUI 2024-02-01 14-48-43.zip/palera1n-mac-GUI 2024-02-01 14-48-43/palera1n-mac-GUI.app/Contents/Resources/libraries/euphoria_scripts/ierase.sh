#!/usr/bin/env bash

# @pwn2owned

sleep 5

#stop asking me if i want to fucking save the damn key
rm -rf ~/.ssh/known_hosts

# Change the current working directory
cd "`dirname "$0"`"


# shitty method (1.0)
#./iproxy 2222 22 &>/dev/null &

# GOOD METHOD! (2.0)
./iproxy 2222:22 > /dev/null 2>&1 &

sleep 2

while true ; do
  result=$(ssh -p 2222 -o BatchMode=yes -o ConnectTimeout=2 -o StrictHostKeyChecking=no -o UserKnownHostsFile=/dev/null root@localhost echo ok 2>&1 | grep Connection)

  if [ -z "$result" ] ; then

sleep 1

# read/write filesystem
./sshpass -p 'alpine' ssh -o StrictHostKeyChecking=no root@localhost -p2222 'mount_filesystems'
        
./sshpass -p 'alpine' ssh -o StrictHostKeyChecking=no root@localhost -p2222 '/usr/sbin/nvram oblit-inprogress=5'

./sshpass -p 'alpine' ssh -o StrictHostKeyChecking=no root@localhost -p2222 'sync'
        
# reboot device
./sshpass -p 'alpine' ssh -o StrictHostKeyChecking=no root@localhost -p2222 '/sbin/reboot'
echo 'ran actnewr'


# Kill iproxy
kill %1 > /dev/null 2>&1
echo ''
echo 'Done. Done. Done!!!'
echo ''
sleep 1

    break

  fi
  echo 'Connection failed. Jailbreak again.'
  break

  sleep 1
  echo '\nPush Complete!\n'
done










# pull file
# ./sshpass -p 'alpine' scp -P 2222 -p root@localhost:"/mnt2/containers/Data/System/054D37B0-4498-4CE6-AC67-5D7FC4DE7F89/Library/internal/data_ark.plist" /Users/user/Desktop/nvjojc03c/GENERATED_ACTIVATION/FairPlay/iTunes_Control/iTunes/;
